﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApp1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Tests
{
    [TestClass()]
    public class ProgramTests
    {
        [TestMethod()]
        [DataRow("1,2,5", 8)]
        [DataRow("1\n,2,3", 6)]
        [DataRow("1,\n2,4", 7)]
        [DataRow("//;\n1;3;4", 8)]
        [DataRow("//$\n1$2$3", 6)]
        [DataRow("//@\n2@3@8", 13)]
        [DataRow("2,1001", 2)]
        [DataRow("//***\n1***2***3", 6)]
        [DataRow("//$,@\n1$2@3", 6)]
        [DataRow("//$,@@\n1$2@@3@@4", 10)]
        [DataRow("//$$$,@\n1$$$2@3$$$4$$$5", 15)]
        public void AddTest(string input,int expectedResult)
        {
            int actualResult = 0;
            Program obj = new Program();
            actualResult = obj.Add(input);
            Assert.AreEqual(actualResult, expectedResult);
        }
        
    }
}