﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
 

namespace ConsoleApp1
{
   public class Program
    {
        private bool isCustomDelimeter ; // flag used to determine if custom delimeter is used in input string or not
        private static char defaultdelimeter = ','; //default delimeter in case no custom delimeter is used
        private static int UpperLimit = 1000; //Upper Limit to ignore numbers greater than specific value
        public static void Main(string[] args)
        {
            Program obj = new Program();
            Console.Write("Enter a string - "); // Takes input from user
            var inputString = Console.ReadLine();
            int sum = obj.Add(inputString);
            Console.Write("The Sum is " + sum+ " ");
        }
        public int Add(string input)
        {
            try
            {
                List<Int32> Numbers = new List<Int32>();
                char delimeter = defaultdelimeter; 
                string[] Customdelimeters = { };
                if (string.IsNullOrEmpty(input))
                    return 0;
                else
                {
                    if (input.StartsWith("//")) //Sign of Custom Delimeter is used
                    {
                        isCustomDelimeter = true;
                        Customdelimeters = getCustomDelimeters(input); 
                    }
                    else
                    {
                        isCustomDelimeter = false;
                    }
                    
                    if (isCustomDelimeter)
                    {
                        //In case of Custom Delimeters the part of input string where custom delimeters will be ignored since we already 
                        //have saved customDelimeters and the second part where numbers are will be used .
                       input = input.Split(new string[] { "\\n", "\n" }, 2, StringSplitOptions.RemoveEmptyEntries)[1];
                       Numbers = (input.Replace("\\n", "").Replace("\n", "").Split(Customdelimeters,StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToList());
                    }
                    else
                    {//In case of No Custom Delimeter only new lines will be ignored and default delimeter will be used 
                        Numbers = (input.Replace("\\n", "").Replace("\n", "").Split(delimeter).Select(int.Parse).ToList());
                    }
                }

                int sum = 0;
                checkNegativeNumbers(Numbers); // Method to check if negative numbers exist in the input string
                Numbers.RemoveAll(x => x > UpperLimit); // Ignoring values greater than specific threshold
                sum = Numbers.Sum(); // Adding all the numbers in the input string
                return sum;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return 0;
            }
        }

        public void checkNegativeNumbers(List<int> Numbers)
        {
            string error = "";
            foreach (int n in Numbers)
            {

                if (n < 0)
                {
                    if (error == "")
                        error = n.ToString();
                    else
                        error = error + "," + n.ToString();
                }
            }
            if (error != "")
                throw new Exception("Negative numbers not allowed" + "Following are negative numbers " + error);
        }
            

        public string[] getCustomDelimeters(string input)
         {

            char[] chars = input.ToCharArray();
            input = input.Split(new string[] { "\\n","\n"},2,StringSplitOptions.RemoveEmptyEntries).FirstOrDefault();
            input = input.Replace("//", "");
            string[] lstCustomDelimeters;
            lstCustomDelimeters = input.Split(',');
            return lstCustomDelimeters;

         }
    }
}
