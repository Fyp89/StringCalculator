﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    public struct Delimeters
    {
        public Char Delimeter { get; set; }
        public int DelimeterLength { get; set; }
    }
}
